# S.A.V.I.O.R Architecture Context

## High-Level Architecture

```text
                    ┌───────────────────────┐
                    │     React Frontend    │
                    │                       │
                    │  PDF Viewer           │
                    │  Element Overlays     │
                    │  Processing Stream    │
                    │  Chat                 │
                    └───────────┬───────────┘
                                │
                         HTTP / SSE
                                │
                    ┌───────────▼───────────┐
                    │    FastAPI Backend    │
                    │                       │
                    │ Upload                │
                    │ Extraction            │
                    │ Processing            │
                    │ Retrieval             │
                    │ Chat                  │
                    └───────┬───────┬───────┘
                            │       │
                     ┌──────▼───┐ ┌─▼───────────┐
                     │Unstructured│ │ Gemini API │
                     └──────┬───┘ └─────┬───────┘
                            │           │
                            ▼           ▼
                         Elements    Vision/LLM
                            │           │
                            └─────┬─────┘
                                  ▼
                             Embeddings
                                  │
                                  ▼
                               Qdrant
```

## Processing Architecture

```text
PDF Upload
    │
    ▼
Local PDF Storage
    │
    ▼
Unstructured
    │
    ▼
Extracted Elements
    │
    ├───────────────┬────────────────┐
    ▼               ▼                ▼
Text             Table             Image
    │               │                │
    ▼               ▼                ▼
Chunking      Structured Text   Gemini Vision
    │               │                │
    └───────────────┴────────────────┘
                    │
                    ▼
              Gemini Embedding
                    │
                    ▼
                  Qdrant
                    │
                    ▼
              Processing Complete
```

## Frontend Architecture

The main document workspace contains two primary panels.

```text
┌──────────────────────────────┬──────────────────────────────┐
│                              │                              │
│         PDF VIEWER           │        RIGHT PANEL           │
│                              │                              │
│ PDF Pages                    │ Processing / Chat            │
│ Element Overlays             │                              │
│ Selection                    │ Extraction Stream            │
│ Source Highlighting          │ Element Inspector            │
│                              │ Chat                         │
│                              │ Retrieval Trace              │
│                              │                              │
└──────────────────────────────┴──────────────────────────────┘
```

The right panel has two primary states:

### Processing State

Display:

* processing progress
* extraction events
* embedding events
* errors

### Ready State

Display:

* chat
* answer sources
* optional retrieval trace

## Backend Architecture

The backend is organized by responsibility.

`API -> Services -> External Providers / Infrastructure`

### API Layer

Responsible for:

* request validation
* response serialization
* streaming endpoints

The API layer should not contain:

* Unstructured processing logic
* embedding logic
* Gemini prompts
* Qdrant query logic

### Services

Services contain application behavior.

Primary domains:

* document
* extraction
* vision
* chunking
* embeddings
* retrieval
* chat

Services should coordinate the pipeline.

### Provider Integrations

External systems should be isolated behind dedicated services.

Examples:

* `UnstructuredExtractor`
* `GeminiVisionService`
* `GeminiEmbeddingService`
* `GeminiChatService`
* `QdrantService`

Avoid spreading provider-specific SDK calls throughout the application.

## Data Flow

### Extraction Layer

```text
PDF
↓
Unstructured
↓
Normalized ExtractedElement
```

The backend should normalize Unstructured output into an application-owned structure.
The rest of the application should not depend directly on raw Unstructured objects.

### Chunking Layer

```text
ExtractedElement[]
↓
Chunking Strategy
↓
RAGChunk[]
```

Each chunk must include:

* `chunk_id`
* `content`
* `element_ids`
* `page_numbers`
* `categories`

### Embedding Layer

```text
RAGChunk
↓
GeminiEmbeddingService
↓
Vector
```

### Vector Storage Layer

Qdrant payload must preserve traceability.

Example conceptual payload:

```json
{
  "chunk_id": "chunk_001",
  "document_id": "document_001",
  "element_ids": [
    "element_001",
    "element_002"
  ],
  "page_numbers": [1],
  "categories": [
    "Title",
    "NarrativeText"
  ],
  "content": "..."
}
```

### Retrieval Flow

```text
User Question
    │
    ▼
Gemini Query Embedding
    │
    ▼
Qdrant Search
    │
    ▼
Retrieved Chunks
    │
    ▼
Retrieval Trace
    │
    ▼
Context Builder
    │
    ▼
Gemini Chat
    │
    ▼
Streaming Answer
```

### Source Navigation

Sources returned from retrieval must contain enough information for the frontend to locate the original PDF element.

At minimum:

* `element_id`
* `page_number`
* `coordinates`
* `category`

The frontend must not attempt to infer source positions from text matching.
The backend must provide explicit metadata.
