# Project Overview

## S.A.V.I.O.R

### Overview

S.A.V.I.O.R is an Explainable Multimodal Retrieval-Augmented Generation application designed for interacting with PDF documents.

The application focuses on making document processing and RAG behavior visible to the user.

Traditional RAG applications typically hide the following pipeline:

```text
PDF
→ Extraction
→ Chunking
→ Embedding
→ Vector Search
→ LLM
```

S.A.V.I.O.R exposes this pipeline visually.

The user can inspect:

* what Unstructured extracted
* where an extracted element exists in the PDF
* what category the element belongs to
* how images were interpreted
* what content was embedded
* what content was retrieved
* which sources were used to answer a question

### Primary User Flow

#### Step 1: Upload

The user uploads one PDF.

The frontend immediately displays the local PDF using a browser object URL.

The user should not need to wait for backend processing before viewing the document.

#### Step 2: Processing

The PDF is uploaded to FastAPI.

The backend processes the PDF using Unstructured.

The backend streams processing events to the frontend using Server-Sent Events.

Example events include:

* document_started
* page_processing
* element_extracted
* image_processing
* image_processed
* chunk_created
* embedding_created
* document_completed
* processing_failed

The frontend displays these events in real time.

#### Step 3: Visual Extraction

As elements are processed, the frontend displays extraction overlays on top of the PDF.

Examples:

* Title
* Paragraph
* Table
* Image

Each overlay represents an extracted document element.

Clicking an element should select the entire extracted element rather than an arbitrary word.

Example:

The PDF contains:

`Nirujogi Prudhvi`

If the user clicks `Prudhvi`, the application should select the entire element:

`Nirujogi Prudhvi`

The UI should visually indicate the element boundary.

#### Step 4: Element Inspection

The user can inspect an extracted element.

The inspector should show information such as:

* Type: Title
* Page: 1
* Text: Nirujogi Prudhvi
* Extraction: Completed
* Embedding: Indexed

Additional metadata may include:

* element ID
* coordinates
* chunk IDs
* image description
* Qdrant indexing status

#### Step 5: Multimodal Processing

Different element categories use different processing strategies.

**Text**
```text
Text
↓
Chunking
↓
Gemini Embedding
↓
Qdrant
```

**Tables**
```text
Table
↓
Structured representation
↓
Text representation
↓
Gemini Embedding
↓
Qdrant
```

**Images**
```text
Image
↓
Gemini Vision
↓
Detailed structured description
↓
Gemini Embedding
↓
Qdrant
```

This project uses Level A multimodal RAG.

Images are converted into rich textual representations before embedding.

The original image is retained locally for visualization and source traceability.

#### Step 6: Chat

After document processing completes, the right panel switches from processing mode to chat mode.

The user can ask questions about the document.

The backend:

1. Generates an embedding for the question.
2. Searches Qdrant.
3. Retrieves relevant chunks.
4. Builds grounded context.
5. Sends the context and question to Gemini.
6. Streams the answer to the frontend.

#### Step 7: Source Traceability

Every answer should include source information.

Example:

```text
Sources

Page 2 · Paragraph
Page 5 · Table
Page 7 · Architecture Image
```

When the user clicks a source:

* The PDF navigates to the source page.
* The relevant element is highlighted.
* The viewer may zoom to the element.
* The element inspector becomes available.

#### Step 8: Retrieval Explainability

S.A.V.I.O.R supports retrieval explainability in Version 1.

The user should be able to inspect:

```text
Question
↓
Query Embedding
↓
Retrieved Chunks
↓
Similarity Scores
↓
Source Elements
↓
Context Sent to Gemini
↓
Generated Answer
```

This feature should be accessible without cluttering the primary chat experience.

A separate expandable panel or toggle is recommended.

### Product Principle

The product should answer two questions:

1. What does the PDF say?
2. How did the system understand and retrieve that information?

The second question is what differentiates S.A.V.I.O.R from ordinary PDF chat applications.
