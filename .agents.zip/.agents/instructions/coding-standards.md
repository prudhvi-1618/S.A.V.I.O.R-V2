# Coding Standards

## General Principles

Prefer:

* clarity
* explicitness
* maintainability
* small focused functions
* meaningful names

Avoid:

* unnecessary abstraction
* premature optimization
* duplicated business logic
* hidden side effects

## Naming

Use descriptive names.

Good:

* `selected_element_id`
* `processing_status`
* `retrieved_chunks`

Avoid:

* `data`
* `result`
* `temp`
* `obj`
* `x`

unless the scope is extremely small and obvious.

## File Size

Do not enforce arbitrary line limits.

However, when a file contains multiple unrelated responsibilities, split it.

A file should have a clear reason to exist.

## Functions

Functions should generally perform one clear task.

Prefer:

* `extract_elements()`
* `normalize_elements()`
* `create_chunks()`
* `generate_embeddings()`
* `store_vectors()`

over:

* `process_everything()`

unless an orchestration function is intentionally coordinating those operations.

## Error Handling

Errors must provide useful context.

Bad:

```python
except Exception:
    return None
```

Better:

```python
except SpecificProviderError as error:
    raise EmbeddingError(
        "Failed to generate embedding"
    ) from error
```

Do not silently swallow errors.

## Python

Follow standard Python conventions.

Use:

* type hints
* Pydantic for API schemas where appropriate
* clear service interfaces

Avoid:

* mutable default arguments
* hidden global state when avoidable
* untyped public service methods

## TypeScript

Use strict TypeScript.

Avoid `any`.

Prefer:

* `type`
* `interface`
* `unknown`
* `discriminated unions`

Use `unknown` when external data has not been validated.

## Validation

Validate external data at system boundaries.

Examples:

* HTTP requests
* Gemini responses
* Unstructured output
* Qdrant payloads

Do not assume external provider responses always match expectations.

## Comments

Comments should explain:

* why a decision exists
* non-obvious behavior
* architectural constraints

Avoid comments that simply restate code.

Bad:

```python
# Increment counter
counter += 1
```

Useful:

```python
# Preserve the original element ID so retrieved chunks can
# navigate back to the exact PDF overlay.
```

## Logging

Log meaningful events.

Good examples:

* Document processing started
* Page processing completed
* Image description generated
* Embedding failed
* Qdrant indexing completed

Do not log:

* API keys
* complete secrets
* sensitive credentials

Avoid excessive logs inside tight loops unless needed for debugging.

## Dependencies

Before adding a dependency:

1. Check whether an existing dependency solves the problem.
2. Prefer standard library functionality when appropriate.
3. Avoid dependencies for trivial utilities.
4. Consider project complexity.

Every dependency should have a reason.

## API Changes

When changing an API:

* Check frontend consumers.
* Update schemas.
* Update types.
* Update relevant tests.
* Preserve backward compatibility when reasonable.

## No Dead Code

Do not leave:

* unused imports
* unused variables
* abandoned functions
* commented-out implementations

Delete obsolete code when replacing it.

## Formatting

Use project-configured formatters and linters.

Do not manually fight formatting tools.

## Golden Standard

Write code that another engineer or coding agent can understand without reading the entire project.
