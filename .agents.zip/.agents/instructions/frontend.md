# Frontend Instructions

## Stack

The frontend uses:

* React
* TypeScript
* Vite
* Tailwind CSS
* React-PDF
* PDF.js

## Architecture

Organize frontend code by feature.

Recommended conceptual structure:

```text
src/
├── app/
├── pages/
├── features/
│   ├── document/
│   ├── pdf-viewer/
│   ├── extraction/
│   ├── chat/
│   └── retrieval/
├── components/
│   ├── ui/
│   └── layout/
├── services/
├── hooks/
├── types/
└── lib/
```

Do not place all application logic inside one `components/` directory.

## Component Responsibilities

### PDF Viewer

Responsible for:

* rendering PDF pages
* zooming
* page navigation
* displaying element overlays

The PDF viewer must not:

* fetch embeddings
* perform extraction
* contain chat logic

### Element Overlay

Responsible for:

* rendering extracted element boundaries
* visual category indication
* click interaction

When a user clicks an element, the entire extracted element must be selected.

Never rely on browser text selection for element selection.

Use backend-provided coordinates and element identifiers.

### Coordinate Handling

PDF coordinates and rendered coordinates may differ.

Create a dedicated coordinate transformation utility.

Do not scatter coordinate conversion logic throughout components.

Conceptual responsibility:

```text
PDF Coordinates
↓
Coordinate Transformer
↓
Rendered Overlay Coordinates
```

Coordinate transformations should account for:

* PDF page dimensions
* rendered page dimensions
* zoom
* page rotation when applicable

## Right Panel States

The document workspace right panel has two primary modes.

### Processing

Show:

* current processing state
* streamed extraction events
* element progress
* embedding progress
* failures

### Ready

Show:

* chat interface
* answer sources
* retrieval explainability

Do not show the complete chat interface before document processing is ready unless the product requirements change.

## SSE Handling

SSE logic should be centralized.

Do not create independent `EventSource` connections inside multiple components.

Create a dedicated abstraction.

Example responsibility:

`useDocumentProcessingStream()`

The hook should:

* connect
* parse events
* update processing state
* handle disconnects
* handle failures
* clean up connections

Components should consume normalized state rather than raw SSE events.

## State Management

Separate server state from UI state.

### Server / API State

Contains:

* processing status
* extracted elements
* chat responses
* retrieval results

### UI State

Contains:

* selected element
* selected source
* current page
* zoom level
* open panels

Avoid storing everything in one global object.

## Source Navigation

When a user clicks an answer source:

1. Set the selected element ID.
2. Navigate to the source page.
3. Ensure the page is rendered.
4. Scroll or zoom to the element.
5. Highlight the element.
6. Optionally open the element inspector.

Source navigation should use explicit metadata.

Never locate sources using approximate text matching.

## Styling

Use Tailwind CSS.

Prefer:

* reusable utility patterns
* component variants where appropriate
* consistent spacing
* responsive layout

Avoid:

* large inline style objects
* arbitrary styles repeated across many components
* global CSS for component-specific behavior

## TypeScript Rules

Do not use:

`any`

unless there is a documented reason.

Prefer explicit interfaces and types.

Use discriminated unions for processing states when appropriate.

Example conceptual pattern:

```typescript
type ProcessingState =
  | { status: "idle" }
  | { status: "processing" }
  | { status: "completed" }
  | { status: "failed"; error: string };
```

## Performance

PDF rendering can be expensive.

Avoid:

* unnecessary rerenders of all PDF pages
* recreating overlays unnecessarily
* storing large PDF objects in React state

Memoize expensive calculations when justified.

Optimize only when needed, but be aware that large PDFs can stress the browser.

## Accessibility

Interactive elements must support:

* keyboard interaction
* visible focus
* semantic buttons
* meaningful labels

Do not make non-interactive `div` elements clickable without appropriate accessibility behavior.

## Frontend Golden Rule

The PDF viewer must remain visually synchronized with backend extraction metadata.

The user should always be able to understand:

*What did the system extract, and where did it come from?*
