# Architecture Instructions

## Purpose

This document defines the architecture rules that must be followed when implementing S.A.V.I.O.R.

## System Boundaries

### Frontend

Responsible for:

* user interaction
* PDF rendering
* element overlays
* processing visualization
* chat interface
* source navigation

The frontend must not:

* process PDFs
* generate embeddings
* call Qdrant directly
* expose Gemini API keys

### Backend

Responsible for:

* PDF processing
* Unstructured integration
* element normalization
* image processing
* Gemini integration
* embedding generation
* Qdrant storage
* retrieval
* answer generation

## Single Active Document Constraint

The system is designed for:

* one user
* one active PDF
* one active processing session

Do not introduce multi-tenant or multi-document complexity unless explicitly requested.

## No Background Worker Architecture

Document processing does not use an external worker system.

Do not add:

* Celery
* Redis queue
* RabbitMQ
* task workers

The FastAPI application performs document processing directly.

Long-running processing must be structured carefully to avoid mixing unrelated API concerns.

The architecture should expose processing state through a service abstraction even though processing currently runs in-process.

This allows future migration without rewriting business logic.

## SSE Architecture

SSE is the primary mechanism for backend-to-frontend processing updates.

Processing events should be explicit.

Recommended event types:

* `processing_started`
* `extraction_started`
* `page_started`
* `element_extracted`
* `table_processed`
* `image_started`
* `image_described`
* `chunk_created`
* `embedding_started`
* `embedding_created`
* `processing_completed`
* `processing_failed`

Do not use vague events such as:

* `status_update`
* `progress`
* `message`

when a more meaningful event type exists.

Every event should contain:

* `event`
* `document_id`
* `timestamp`
* `data`

## Domain Objects

### ExtractedElement

Represents an atomic extraction result.

Required conceptual fields:

* `id`
* `document_id`
* `category`
* `text`
* `page_number`
* `coordinates`
* `metadata`

Optional fields:

* `image_path`
* `table_html`
* `image_description`

### RAGChunk

Represents a retrieval unit.

Required fields:

* `id`
* `document_id`
* `content`
* `element_ids`
* `page_numbers`
* `categories`

### RetrievalResult

Represents a vector search result.

Required fields:

* `chunk_id`
* `score`
* `content`
* `element_ids`
* `page_numbers`

## Provider Isolation

External dependencies must be isolated.

Bad:

```python
# Random API route
model = Gemini(...)
```

Good:

```text
services/
    embeddings/
        gemini_embedding_service.py
```

The same principle applies to:

* Gemini Vision
* Gemini Chat
* Qdrant
* Unstructured

## Extraction Normalization

Raw Unstructured objects must be converted into internal application models.

Do not pass raw Unstructured objects into:

* API responses
* chunking
* retrieval
* frontend logic

Use a mapper or adapter.

Example conceptual flow:

```text
Unstructured Element
↓
Element Mapper
↓
ExtractedElement
```

## Traceability Requirement

Every stage must preserve references to the previous stage.

```text
Element
↓
Chunk
↓
Vector
↓
Retrieved Result
↓
Answer Source
```

It must always be possible to answer:

*Which original PDF element produced this answer?*

If an implementation loses this mapping, it is architecturally incorrect.

## Failure Handling

Processing failures must be explicit.

Examples:

* OCR failure
* Image processing failure
* Embedding failure
* Qdrant failure
* Gemini API failure

Do not silently skip failures.

Partial processing may be supported, but the processing state must clearly indicate what succeeded and what failed.

## Dependency Rule

Do not add dependencies without a clear reason.

Before adding a dependency, ask:

1. Does the existing stack already solve this?
2. Is the dependency necessary?
3. Does it introduce architectural complexity?
4. Is it appropriate for a single-user application?

Prefer simple solutions.
