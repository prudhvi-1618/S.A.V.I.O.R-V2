# Backend Instructions

## Stack

The backend uses:

* Python
* FastAPI
* uv
* Unstructured
* Gemini
* Qdrant

## Python Package Management

Use `uv`.

Do not introduce Poetry or Pipenv.

Dependencies must be managed through the project's `pyproject.toml`.

Preferred commands:

* `uv sync`
* `uv add <package>`
* `uv run <command>`

Do not manually modify dependency lock files unless necessary.

## Backend Responsibilities

The backend handles:

* PDF upload.
* Local file storage.
* Document extraction.
* Element normalization.
* Image processing.
* Table processing.
* Chunking.
* Embedding generation.
* Qdrant indexing.
* Retrieval.
* Gemini answer generation.
* SSE processing events.
* Streaming chat responses.

## API Layer Rules

API routes should be thin.

Routes should handle:

* input validation
* dependency access
* service calls
* response construction

Routes should not contain:

* extraction algorithms
* embedding implementation
* prompt construction
* Qdrant implementation details

## Service Layer

Use focused services.

Recommended domains:

```text
services/
├── document/
├── extraction/
├── vision/
├── chunking/
├── embeddings/
├── vector_store/
├── retrieval/
└── chat/
```

Each service should have a clear responsibility.

Avoid one large `rag_service.py` that performs the entire application.

## Document Processing Pipeline

The conceptual pipeline is:

```text
PDF
↓
Unstructured
↓
Normalized Elements
↓
Element Router
├── Text
├── Table
└── Image
↓
Content Representation
↓
Chunking
↓
Gemini Embedding
↓
Qdrant
```

### Unstructured

Use Unstructured with:

`strategy="auto"`

Unstructured is responsible for document partitioning and extraction.

Do not manually implement OCR unless there is a documented reason.

The backend must normalize Unstructured results into application-owned models.

### Text Processing

Text elements may include:

* Title
* NarrativeText
* ListItem
* Header
* Footer

Do not blindly concatenate the entire PDF into one string.

Preserve element boundaries.

Chunk content while preserving element references.

### Table Processing

Tables must be supported in Version 1.

Preserve structured table information when available.

The representation sent to embeddings should be understandable as text.

Possible representations include:

* HTML converted to normalized text
* Markdown
* structured text

Do not embed meaningless raw binary representations.

Every table chunk must retain:

* page number
* source element ID
* table metadata

### Image Processing

For image elements:

```text
Extracted Image
↓
Gemini Vision
↓
Detailed Description
↓
Text Representation
↓
Gemini Embedding
↓
Qdrant
```

The image description should be useful for retrieval.

Do not use generic prompts such as:

*Describe this image.*

The image understanding output should capture:

* image type
* summary
* important objects
* visible text
* relationships
* important information relevant to the document

Store the resulting representation in metadata and vector payloads.

## Gemini Isolation

Do not call Gemini directly throughout the application.

Create focused integrations.

Conceptually:

* `GeminiVisionService`
* `GeminiEmbeddingService`
* `GeminiChatService`

This keeps provider logic isolated.

## Embeddings

Use Gemini embeddings.

Embedding generation should be centralized.

Do not generate embeddings from API routes directly.

The embedding service should:

* receive normalized content
* generate embeddings
* validate output
* return vectors

## Qdrant

Qdrant is the vector database.

Do not use Qdrant as a replacement for arbitrary application state.

Qdrant stores vectorized RAG content and metadata.

Every point should contain traceability metadata.

At minimum:

* `document_id`
* `chunk_id`
* `element_ids`
* `page_numbers`
* `categories`
* `content`

## Retrieval

The retrieval pipeline:

```text
Question
↓
Gemini Query Embedding
↓
Qdrant Search
↓
Retrieved Results
↓
Optional Filtering
↓
Context Builder
↓
Gemini Chat
```

Retrieved results must preserve similarity scores.

Similarity scores must be available for the retrieval explainability feature.

## Context Construction

Do not simply concatenate retrieved chunks without structure.

The context builder should clearly separate sources.

Conceptual format:

```text
SOURCE 1
Page: 2
Category: NarrativeText
Content:
...

SOURCE 2
Page: 5
Category: Image
Description:
...
```

The LLM should be instructed to answer only from available document context.

If the answer is not supported by the retrieved context, the system should say so.

## Chat Memory

Chat memory is in-memory only.

Do not persist chat history.

The application may use an in-memory session object or equivalent structure.

Memory is lost when:

* the server restarts
* the session is cleared

This is acceptable for Version 1.

## Streaming

Chat responses should be streamed.

Processing progress should use SSE.

Keep these concerns separate.

* Processing stream: Document pipeline events
* Chat stream: Generated answer tokens/events

Do not mix document processing events with chat generation events.

## Error Handling

Use explicit application errors.

Examples:

* `DocumentProcessingError`
* `ExtractionError`
* `VisionProcessingError`
* `EmbeddingError`
* `VectorStoreError`
* `RetrievalError`
* `ChatGenerationError`

Do not catch broad exceptions and silently return success.

Log useful context.

Never expose secrets in error messages.

## File Storage

Temporary local storage:

```text
backend/data/
├── uploads/
└── extracted_images/
```

Use application configuration for paths.

Do not hardcode paths throughout services.

## Async Rules

Use async where it provides a clear benefit.

Do not make every function async by default.

CPU-heavy or blocking library calls should be handled carefully.

Do not block unrelated application behavior unnecessarily.

Avoid introducing background workers to solve this problem.

## Backend Golden Rule

Every answer must be traceable back to the original document elements that contributed to it.
