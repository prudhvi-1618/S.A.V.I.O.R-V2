# Workflow: Debug an Issue

## Step 1: Reproduce

Do not immediately modify code.

First determine:

* exact failing behavior
* expected behavior
* reproduction steps
* affected component or service

## Step 2: Identify the Layer

Classify the issue.

Possible layers:

```text
Frontend
↓
API
↓
Document Processing
↓
Unstructured
↓
Gemini
↓
Embedding
↓
Qdrant
↓
Retrieval
↓
Chat
```

Avoid debugging the entire application at once.

## Step 3: Inspect Inputs and Outputs

At the failing boundary, verify:

```text
Input
↓
Transformation
↓
Output
```

Examples:

* PDF → Unstructured Elements
* Elements → Chunks
* Chunks → Embeddings
* Question → Retrieved Results

Find the first stage where the output becomes incorrect.

## Step 4: Use Existing Logs

Check logs before adding new logging.

If additional logging is required:

* keep it temporary unless useful long term
* avoid logging secrets
* include document or element identifiers when useful

## Step 5: Create a Minimal Reproduction

Reduce the problem.

Examples:

Instead of testing a 100-page PDF:
* Test one page.

Instead of processing all element categories:
* Test one image.

Instead of debugging the full RAG pipeline:
* Test retrieval independently.

## Step 6: Check External Dependencies

For provider-related issues, verify:

* **Unstructured**
  * input file is valid
  * required dependencies exist
  * extraction strategy is correct
* **Gemini**
  * credentials are configured
  * request format is valid
  * response is being parsed correctly
* **Qdrant**
  * service is running
  * collection exists
  * vector dimensions match
  * payload is valid

## Step 7: Fix the Root Cause

Do not fix symptoms if the underlying boundary is incorrect.

Prefer:
* Correct data model

over:
* Multiple special-case patches

## Step 8: Add Regression Coverage

If practical, add a test that would have caught the issue.

## Step 9: Verify End-to-End

For pipeline issues, verify the full affected path.

Example:

```text
PDF
↓
Extraction
↓
Embedding
↓
Qdrant
↓
Retrieval
```

Do not stop after verifying only the immediate function if the integration may still be broken.
