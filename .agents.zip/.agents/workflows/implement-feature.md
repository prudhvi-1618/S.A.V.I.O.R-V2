# Workflow: Implement a Feature

Use this workflow for new functionality.

## Step 1: Understand the Request

Identify:

* user-facing behavior
* affected frontend features
* affected backend services
* API changes
* data flow changes

Do not start coding immediately if the request is ambiguous.

## Step 2: Read Relevant Context

Always read:

* `.agents/context/project-overview.md`
* `.agents/context/architecture.md`

Then read the relevant instructions.

For frontend:

* `.agents/instructions/frontend.md`

For backend:

* `.agents/instructions/backend.md`

For cross-cutting work:

* `.agents/instructions/architecture.md`
* `.agents/instructions/coding-standards.md`

## Step 3: Inspect Existing Code

Before creating new files:

* Look for an existing feature.
* Look for similar patterns.
* Check existing service boundaries.
* Check existing API contracts.

Do not create duplicate abstractions.

## Step 4: Design the Smallest Correct Change

Identify:

```text
Input
↓
Processing
↓
Output
```

Ask:

* What layer owns this behavior?
* What existing service should be extended?
* Does this require a new abstraction?

Avoid large refactors unless necessary.

## Step 5: Implement Backend First When Appropriate

For features requiring backend support:

1. Define schemas.
2. Implement or update services.
3. Add API endpoints.
4. Test behavior.
5. Update frontend integration.

Do not put business logic directly into routes.

## Step 6: Implement Frontend

The frontend should:

* Use typed API contracts.
* Handle loading states.
* Handle error states.
* Handle empty states.
* Preserve PDF synchronization when applicable.

Do not tightly couple unrelated components.

## Step 7: Preserve Traceability

For any RAG-related feature, verify:

```text
PDF Element
↓
Chunk
↓
Vector
↓
Retrieved Result
↓
Answer Source
```

If the feature breaks this chain, fix the design.

## Step 8: Test

Run relevant tests.

At minimum verify:

* happy path
* invalid input
* provider failure when applicable
* traceability

## Step 9: Review

Before finishing:

* remove unused code
* verify types
* verify imports
* verify error handling
* verify architecture constraints
* ensure no unnecessary dependency was introduced

## Step 10: Report

Summarize:

* what changed
* important design decisions
* tests run
* known limitations
