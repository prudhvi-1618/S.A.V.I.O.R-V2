# Workflow: Testing

## Testing Goal

Tests should verify behavior and important architecture boundaries.

The project uses:

`pytest`

for backend testing.

## Test Categories

### Unit Tests

Test isolated behavior.

Examples:

* Element normalization
* Coordinate transformation
* Chunk creation
* Context construction
* Payload generation

External providers should be mocked.

Do not call Gemini or Qdrant in ordinary unit tests.

### Integration Tests

Test component interactions.

Examples:

* Extraction service → element mapper
* Chunking → embedding payload
* Qdrant service → test collection

Use isolated test configuration where appropriate.

### API Tests

Test FastAPI endpoints.

Verify:

* valid requests
* invalid requests
* response schemas
* error responses

## Required Tests for Pipeline Changes

When changing extraction:

Test:
```text
Input
↓
Normalized Element
```

Verify:
* category
* text
* page number
* coordinates

When changing chunking:

Verify:
* element references are preserved
* page numbers are preserved
* chunk content is correct

When changing vector storage:

Verify:
* vector dimensions
* payload metadata
* element IDs
* chunk IDs

When changing retrieval:

Verify:
* query embedding generation
* Qdrant search invocation
* result normalization
* similarity scores
* source metadata

When changing chat:

Verify:
* retrieved context is passed correctly
* unsupported answers are handled
* source references are returned

## Test Naming

Use descriptive names.

Good:
`test_normalize_title_element_preserves_page_number`

Bad:
`test_one`
`test_service`

## Arrange, Act, Assert

Prefer:

* Arrange
* Act
* Assert

Example conceptual structure:

```python
def test_chunk_preserves_source_element_ids():
    # Arrange

    # Act

    # Assert
```

## External Services

Do not depend on live external services for normal test execution.

Mock:

* Gemini
* Unstructured when testing unrelated logic
* Qdrant when testing unrelated logic

Integration tests may use real local services when explicitly configured.

## Before Completing Work

Run relevant tests.

For backend work:

`uv run pytest`

Run focused tests first when possible.

Example:

`uv run pytest tests/services/test_chunking.py`

Then run the relevant broader test suite.

## Testing Golden Rule

A test should verify meaningful behavior.

Do not write tests solely to increase coverage numbers.

One important recommendation.
