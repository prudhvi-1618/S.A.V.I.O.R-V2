# S.A.V.I.O.R — AI Agent Instructions

## Purpose

This directory provides persistent project context and implementation instructions for AI coding agents working on S.A.V.I.O.R.

Before making significant changes, read the relevant project context and instructions.

## Required Reading Order

Start with:

1. `context/project-overview.md`
2. `context/architecture.md`
3. `instructions/architecture.md`

Then read the relevant instruction file:

* Frontend work → `instructions/frontend.md`
* Backend work → `instructions/backend.md`
* General coding decisions → `instructions/coding-standards.md`

For specific tasks:

* Implementing a feature → `workflows/implement-feature.md`
* Debugging → `workflows/debug.md`
* Testing → `workflows/test.md`

## Project Identity

S.A.V.I.O.R is an Explainable Multimodal RAG application for PDF documents.

The application allows a user to:

* Upload a PDF.
* Immediately view the PDF.
* Process the document using Unstructured.
* Extract structured document elements.
* Visualize extracted elements over the original PDF.
* Inspect element metadata.
* Process document images with Gemini Vision.
* Generate embeddings with Gemini.
* Store vectors in Qdrant.
* Chat with the processed document.
* View sources used for answers.
* Click sources and navigate to the original PDF location.
* Inspect retrieval behavior.

## Technology Stack

### Frontend
* React
* TypeScript
* Vite
* Tailwind CSS
* React-PDF / PDF.js

### Backend
* Python
* FastAPI
* uv
* Unstructured

### AI
* Gemini Vision
* Gemini Embeddings
* Gemini LLM

### Vector Database
* Qdrant

### Real-Time Communication
* Server-Sent Events (SSE)

### Testing
* pytest

## Non-Negotiable Architecture Decisions

### No Traditional Database

Do not introduce:

* PostgreSQL
* MySQL
* MongoDB
* SQLite

Qdrant is the only persistent data store for vector data.

### No Background Workers

Do not introduce:

* Celery
* Redis queues
* RabbitMQ
* Dramatiq
* background worker services

The application supports:

* one user
* one active document
* one active processing pipeline

Document processing happens directly inside the FastAPI application lifecycle.

### In-Memory Chat History

Chat history is temporary.

Do not persist chat messages.

Use an in-memory structure for the active application session.

### Local File Storage

Files may be temporarily stored in:

```text
backend/data/
├── uploads/
└── extracted_images/
```

Do not introduce cloud storage unless explicitly requested.

## Core Data Model

The system has three conceptual layers.

### 1. Extracted Elements

Elements are atomic pieces extracted from the PDF.

Examples:

* Title
* NarrativeText
* ListItem
* Table
* Image

Elements preserve metadata such as:

* element ID
* document ID
* page number
* category
* coordinates
* extracted text
* image path when applicable

Elements are used for:

* PDF highlighting
* extraction visualization
* element inspection
* source navigation

### 2. RAG Chunks

Chunks are retrieval units.

A chunk may contain:

* one element
* multiple related elements

Chunks must always preserve references to their original elements.

Example:

```text
chunk_001
├── element_001
├── element_002
└── element_003
```

Chunks are used for:

* embedding
* retrieval
* context construction

### 3. Vectors

Vectors are embeddings stored in Qdrant.

Every vector payload must preserve enough metadata to trace the result back to:

* chunk
* element IDs
* page numbers
* element categories

The fundamental relationship is:

```text
PDF
 ↓
Unstructured
 ↓
Elements
 ↓
Chunks
 ↓
Embeddings
 ↓
Qdrant
 ↓
Retrieval
 ↓
LLM Answer
```

Do not merge these layers into one abstraction.

## Project Philosophy

S.A.V.I.O.R is not a basic "chat with PDF" application.

The main differentiators are:

* Visual extraction.
* Element-level inspection.
* Multimodal document understanding.
* Explainable retrieval.
* Source traceability.

Every feature should preserve these capabilities.

## Agent Rules

Before implementing:

1. Understand the existing architecture.
2. Read the relevant instructions.
3. Identify the affected layers.
4. Reuse existing abstractions.
5. Avoid unnecessary dependencies.
6. Keep changes focused.
7. Run relevant tests.
8. Do not silently change architecture decisions.

If an architectural change is necessary, explicitly explain why before making it.

## Important Rule

Never implement functionality merely because it is common in a RAG project.

The implementation must fit S.A.V.I.O.R's requirements and constraints.
